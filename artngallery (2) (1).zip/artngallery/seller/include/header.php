<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Online Art & Gallery</title>
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/style.css" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="css/font-awesome.min.css" />
	<link rel="stylesheet" type="text/css" href="css/font-awesome.css" />
	<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Muli:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">
<link href='css/simplelightbox.min.css' rel='stylesheet' type='text/css'>
	<script src="js/jquery-2.1.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/ekko-lightbox.js"></script>
<link href="https://cdn.datatables.net/1.10.21/css/dataTables.bootstrap.min.css" rel="stylesheet">

  </head>
<body>


<section id="header" class="clearfix navbar-inverse navbar-fixed-top">

	<nav class="navbar navbar-default ">
        <div class="container clearfix">
		    
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header clearfix page-scroll">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
				<a href="sdashboard.php" class="navbar-brand">Seller <span>Portal</span></a>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse clearfix" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
                    
					
					<li class="dropdown">
						  <a class="tag_menu border_none" href="#" data-toggle="dropdown" role="button" aria-expanded="false">Paintings<span class="caret"></span></a>
						  <ul class="dropdown-menu drop_2" role="menu">
							<li>
                        <a  href="paintings.php">Add Paintings</a>
                    </li>
<li>
                        <a  href="mpaintings.php">Manage Paintings</a>
                    </li>
					<li>
                        <a  href="#">View Ordered Paintings</a>
                    </li>
					</ul>
						</li>
                    
					<li>
                        <a class="tag_menu" href="purchasehistory.php">Purchase History</a>
                    </li>
					
					
					
					
					
						
					<li class="dropdown">
						  <a class="tag_menu border_none" href="#" data-toggle="dropdown" role="button" aria-expanded="false">Settings<span class="caret"></span></a>
						  <ul class="dropdown-menu drop_2" role="menu">
							<li>
                        <a  href="#">Account Settings</a>
                    </li>
<li>
                        <a  href="changepassword.php">Password Settings</a>
                    </li>
<li>
                        <a  href="../seller.php">Logout</a>
                    </li>
					</ul>
						</li>
					
                </ul>
				 
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container-fluid -->
    </nav>
	
</section>