<?php 
ob_start();
include('include/header.php');
include('include/connection.php');
?>		
			<section id="contact_us">	
    <div class="container">
        <div class="row">
		<div class="row">
			<div class="col-sm-12 text-center">
				
			</div>
		</div><br>
            <div class="col-lg-3 col-md-2"></div>
            <div class="col-lg-6 col-md-8 login-box">
                <div class="col-lg-12 login-key">
                    <i class="fa fa-key" aria-hidden="true"></i> <span class="login-title">
                    Change Password
                </span>
                </div>
               

                <div class="col-lg-12 login-form">
                    <div class="col-lg-12 login-form">
                        <form action="changepassword.php" method="post" id="cpass-form">
                            
                            <div class="form-group">
                                <label class="form-control-label">OLD PASSWORD</label>
                                <input type="password" name="pass" class="form-control" required>
                            </div>
<div class="form-group">
                                <label class="form-control-label">NEW PASSWORD</label>
                                <input type="password" name="npass" class="form-control" required>
                            </div>
							<div class="form-group">
                                <label class="form-control-label">CONFIRM PASSWORD</label>
                                <input type="password" name="cpass" class="form-control" required>
                            </div>
                            <div class="col-lg-12 loginbttm">
                                <div class="col-lg-6 login-btm login-text">
                                   
                                </div>
                                <div class="col-lg-6 login-btm login-button">
                                    <button type="submit" name="btn_cpass" class="btn btn-outline-primary">SUBMIT</button>
                                
								 </div>
                            </div>
                        </form>
                    </div>
                </div>
				<?php
                              if(isset($_POST['btn_cpass']))
                              {
                                   $old_pass=trim(md5($_POST['pass']));
                                   $pass=trim($_POST['npass']);
                                   $repass=trim($_POST['cpass']);
                                   if(!empty($old_pass) && !empty($pass) && !empty($repass))
                                   {
									   $query=mysqli_query($connect,"select * from seller where sid='".$_SESSION['seller_id']."'");
                                        if(mysqli_num_rows($query)>0)
                                        {
                                         $row=mysqli_fetch_assoc($query);
											
											//echo $row['password'];
                                            if($old_pass==$row['pass'])
                                            {
                                                if($pass==$repass)
													
												{ 
												$new_pass=md5($pass);
                                                $qry="update seller set pass='$new_pass' where sid='".$_SESSION['seller_id']."'";
                                                    
                                                    if(mysqli_query($connect,$qry))
                                                    {
                                                        echo '<div class="col-lg-12 alert alert-success">Seller Password change Successfully</div>';
  header("refresh:1;url=../seller.php"); 
                                                    }
                                                    else
                                                    {
                                                        echo '<div class="col-lg-12 alert alert-danger">Problem Occur, Try again.</div>';
                                                    }
                                                }
                                                else
                                                {
                                                    echo '<div class="col-lg-12 alert alert-danger">Password and Confirm password mismatch.</div>';
                                                }
                                            }
                                            else
                                            {
                                                echo'<div class="col-lg-12 alert alert-danger">Old Password is incorrect.</div>';
                                            }
                                        }
                                   }
                                   else
                                   {
                                    echo '<div class="alert alert-danger">All Fields required.</div>';
                                   } 
                              }
                              
                          ?>     
        
            </div>
        </div>



</div>
</section>

<script>
  $(document).ready(function($) {
        
				$("#cpass-form").validate({
                rules: {
                                      
                    pass: {
                        required: true,
                        minlength: 8
                    },
					npass: {
                        required: true,
                        minlength: 8
                    },
					cpass: {
                        required: true,
                        minlength: 8
                    }
                 
                },
                messages: {
                                       
                    pass: {
                        required: "Please provide old password",
                        minlength: "Your password must be at least 8 characters long"
                    },
					npass: {
                        required: "Please provide new password",
                        minlength: "Your password must be at least 8 characters long"
                    },
					cpass: {
                        required: "Please provide confirm password",
                        minlength: "Your password must be at least 8 characters long"
                    }
                },
                 
                submitHandler: function(form) {
                    form.submit();
                }
                
            });
    });
	</script>


<?php 
include('include/footer.php');
ob_end_flush();
?>