-- phpMyAdmin SQL Dump
-- version 2.11.2.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Sep 21, 2020 at 10:56 PM
-- Server version: 5.0.45
-- PHP Version: 5.2.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- Database: `artngallery`
--

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(100) NOT NULL auto_increment,
  `cid` varchar(100) NOT NULL,
  `cname` varchar(100) NOT NULL,
  `cimg` varchar(100) NOT NULL,
  `cstatus` varchar(100) NOT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `cid`, `cname`, `cimg`, `cstatus`) VALUES
(3, 'CG3', 'kumar', 'upload/whatsapp image 2020-09-18 at 7.34.40 am.jpeg', '1');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `cid` int(100) NOT NULL auto_increment,
  `fullname` varchar(100) NOT NULL,
  `uname` varchar(100) NOT NULL,
  `pass` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `mobile` varchar(100) NOT NULL,
  `address` text NOT NULL,
  UNIQUE KEY `cid` (`cid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`cid`, `fullname`, `uname`, `pass`, `email`, `mobile`, `address`) VALUES
(2, 'Rajat', 'akumar', '25d55ad283aa400af464c76d713c07ad', 'rajat@gmail.com', '8699311697', 'phagwara');

-- --------------------------------------------------------

--
-- Table structure for table `myadmin`
--

CREATE TABLE `myadmin` (
  `id` int(100) NOT NULL auto_increment,
  `uname` varchar(100) NOT NULL,
  `pass` varchar(100) NOT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `myadmin`
--

INSERT INTO `myadmin` (`id`, `uname`, `pass`) VALUES
(1, 'admin', '25f9e794323b453885f5181f1b624d0b');

-- --------------------------------------------------------

--
-- Table structure for table `painting_details`
--

CREATE TABLE `painting_details` (
  `id` int(100) NOT NULL auto_increment,
  `pid` varchar(100) NOT NULL,
  `cid` varchar(100) NOT NULL,
  `sid` varchar(100) NOT NULL,
  `sname` varchar(100) NOT NULL,
  `pname` varchar(100) NOT NULL,
  `pdesc` text NOT NULL,
  `pprice` varchar(100) NOT NULL,
  `pfeatures` text NOT NULL,
  `pimg` varchar(100) NOT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `painting_details`
--

INSERT INTO `painting_details` (`id`, `pid`, `cid`, `sid`, `sname`, `pname`, `pdesc`, `pprice`, `pfeatures`, `pimg`) VALUES
(2, 'PT2', 'CG3', '1', 'Harjot Kaur', 'aa', 'dad', '23', 'vhhvgh', 'upload/hydrangeas.jpg'),
(3, 'PT3', 'CG3', 'admin', 'admin', 'aab', 'uuy', '23', 'vyuu', 'upload/whatsapp image 2020-09-18 at 7.34.39 am.jpeg');

-- --------------------------------------------------------

--
-- Table structure for table `seller`
--

CREATE TABLE `seller` (
  `sid` int(11) NOT NULL auto_increment,
  `fullname` varchar(100) NOT NULL,
  `uname` varchar(100) NOT NULL,
  `pass` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `mobile` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  UNIQUE KEY `sid` (`sid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `seller`
--

INSERT INTO `seller` (`sid`, `fullname`, `uname`, `pass`, `email`, `mobile`, `address`) VALUES
(1, 'Harjot Kaur', 'harjot', '25f9e794323b453885f5181f1b624d0b', 'harjot@gmail.com', '8699311697', 'phagwara');
