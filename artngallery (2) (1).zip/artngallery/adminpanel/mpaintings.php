<?php 
include('include/header.php');
include('include/connection.php');
?>
	
			
<section id="contact_us">	
    <div class="container">
	<div class="row">
            <div class="col-lg-12 login-key my-align">
                     <span class="login-title " >
                    Manage Paintings
                </span> 
			</div>
            		<div class="col-md-12"> 
            <?php
                          if(isset($_GET['id']))
                          {
                            
                            $query_delete=mysqli_query($connect,"delete from painting_details where id='".$_GET['id']."'");
                            if(mysqli_affected_rows($connect)>0)
                            {
								echo '<div class="alert alert-success">Category deleted Successfully</div>';
								 
								}
                          }
                           ?></div>
			<div class="col-md-12"> 		
 <table id="example" class="table table-striped table-bordered" style="width:100%">
        <thead>
            <tr>
                <th>ID</th>
				<th>Painting ID</th>
                <th>Painting Category</th>
               <th>Seller ID</th>
               <th>Seller Name</th>
			   <th>Painting Name</th>
			   <th>Painting Description</th>
			   <th>Painting Price($)</th>
<th>Painting Features</th>
<th>Painting Image</th>               
			   <th>Action</th>
            </tr>
        </thead>
        <tbody>
		<?php
                                      $query=mysqli_query($connect,"select * from painting_details");
                                      if(mysqli_num_rows($query)>0)
                                      {
                                           while($row=mysqli_fetch_array($query))
                                           {
                                                ?>
            <tr>
               <td><?php echo $row['id']; ?></td>
                 <td><?php echo $row['pid']; ?></td>
               <td><?php echo $row['cid']; ?></td>
                                     <td><?php echo $row['sid']; ?></td>
               <td><?php echo $row['sname']; ?></td>
            
                                <td><?php echo $row['pname']; ?></td>
								 <td><?php echo $row['pdesc']; ?></td>
								  <td><?php echo $row['pprice']; ?></td>
								  <td><?php echo $row['pfeatures']; ?></td>
								 
								<?php  if($row['sid']!='admin')
								  {?>
									  <td><img src="../seller/<?php echo $row['pimg']; ?>" height="100" width="150" /></td>
								<?php  }
								  else
								  {?>
								   <td><img src="<?php echo $row['pimg']; ?>" height="100" width="150" /></td>
                   <?php  } ?>
                <td><a href="upaintings.php?id=<?php echo $row['id'] ?>" class="btn btn-primary btn-xs">Update</a>
												  <a href="mpaintings.php?id=<?php echo $row['id'] ?>" onClick="return confirm('Are You Sure to Delete?')" class="btn btn-danger btn-xs">Delete</a>
												  </td>                                  
            </tr>
			 <?php
                                           }   
                                      } 
                                      ?>
        </tbody>
</table>

	</div>
	</div>			
</div>
</section>




<?php 
include('include/footer.php');
?>