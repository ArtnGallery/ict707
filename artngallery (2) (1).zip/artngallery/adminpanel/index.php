<?php 
include('include/header.php');
include('include/connection.php');
?>
	 		
			<section id="contact_us">	
    <div class="container">
        <div class="row">
		
            <div class="col-lg-12 col-md-10 login-box2">
                <div class="col-lg-12 login-key">
                    <i class="fa fa-user" aria-hidden="true"></i> <span class="login-title">
                  Welcome Admin
                </span>
                </div>
				 <div class="row">
<div class="col-md-3">
          <div class="box">
            <i class="fa fa-info-circle alert-info"></i>
            <div class="info">
              <h3 class="red-ico">Overall</h3> <span></span>
              <p>Quick Info</p>
            </div>
          </div>
        </div>
	  <div class="col-md-3">
          <div class="box">
            <i class="fa fa-user alert-success"></i>
            <div class="info">
              <h3 class="blue-ico">
			  <?php 
                          $query = "SELECT COUNT(*) FROM seller";
                          $result = mysqli_query($connect, $query) or die(mysqli_error($db));
                          while ($row = mysqli_fetch_array($result)) {
                              echo "$row[0]";
                            }
                          ?>
			  </h3> <span></span>
              <p>Seller(s)</p>
            </div>
          </div>
        </div>
        <div class="col-md-3">
          <div class="box">
            <i class="fa fa-user alert-warning"></i>
            <div class="info">
              <h3 class="red-ico"><?php 
                          $query = "SELECT COUNT(*) FROM customer";
                          $result = mysqli_query($connect, $query) or die(mysqli_error($db));
                          while ($row = mysqli_fetch_array($result)) {
                              echo "$row[0]";
                            }
                          ?></h3> <span></span>
              <p>Customer(s)</p>
            </div>
          </div>
        </div>
        <div class="col-md-3">
          <div class="box">
            <i class="fa fa-book alert-danger"></i>
            <div class="info">
              <h3 class="blue-ico"><?php 
                          $query = "SELECT COUNT(*) FROM painting_details";
                          $result = mysqli_query($connect, $query) or die(mysqli_error($db));
                          while ($row = mysqli_fetch_array($result)) {
                              echo "$row[0]";
                            }
                          ?></h3> <span></span>
              <p>Painting(s)</p>
            </div>
          </div>
        </div>
      </div>
 
               <div class="font-icon-list col-lg-2 col-md-2">
                <i class="fa fa-list red-ico" aria-hidden="true"></i>
                     <p><a  href="#"><span>Manage Categories
					</span>
					</a></p>
               </div>
 <div class="font-icon-list col-lg-2 col-md-2">
                <i class="fa fa-user blue-ico" aria-hidden="true"></i>
                     <p><a  href="#"><span>Add Seller
					</span>
					</a></p>
               </div> <div class="font-icon-list col-lg-2 col-md-2">
                <i class="fa fa-book red-ico" aria-hidden="true"></i>
                     <p><a  href="#"><span>Manage Paintings
					</span>
					</a></p>
               </div> 
			   <div class="font-icon-list col-lg-2 col-md-2">
                <i class="fa fa-shopping-cart blue-ico" aria-hidden="true"></i>
                     <p><a  href="#"><span>Purchase History
					</span>
					</a></p>
               </div>
               <div class="font-icon-list col-lg-2 col-md-2">
                <i class="fa fa-sign-out red-ico" aria-hidden="true"></i>
                     <p><a  href="admin.php"><span>Logout
					</span>
					</a></p>
               </div>
            </div>
        </div>

    

</div>
</section>




<?php 
include('include/footer.php');
?>