<?php 
include('include/header.php');
include('include/connection.php');
?>
	
			
<section id="contact_us">	
    <div class="container">
	<div class="row">
            <div class="col-lg-12 login-key my-align">
                     <span class="login-title " >
                    Manage Customers
                </span> 
			</div>
            
			<div class="col-md-12"> 		
 <table id="example" class="table table-striped table-bordered" style="width:100%">
        <thead>
            <tr>
                <th>Seller ID</th>
                <th>Full Name</th>
               <th>Username</th>
               <th>Email</th>
			   <th>Mobile</th>
			   
			   <th>Address</th>
			   
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
		<?php
                                      $query=mysqli_query($connect,"select * from seller");
                                      if(mysqli_num_rows($query)>0)
                                      {
                                           while($row=mysqli_fetch_array($query))
                                           {
                                                ?>
            <tr>
               <td><?php echo $row['sid']; ?></td>
                                                  
                <td><?php echo $row['fullname']; ?></td>
                                <td><?php echo $row['uname']; ?></td>
								 <td><?php echo $row['email']; ?></td>
								  <td><?php echo $row['mobile']; ?></td>
								  <td><?php echo $row['address']; ?></td>
                <td><a href="updatemarketer.php?id=<?php echo $row['id'] ?>" class="btn btn-primary btn-xs">Update</a>
												  <a href="viewmarketer.php?id=<?php echo $row['id'] ?>" class="btn btn-danger btn-xs">Delete</a>
												  </td>                                  
            </tr>
			 <?php
                                           }   
                                      } 
                                      ?>
        </tbody>
</table>

	</div>
	</div>			
</div>
</section>




<?php 
include('include/footer.php');
?>