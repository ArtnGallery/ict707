<?php 
include('include/header.php');
include('include/connection.php');
?>
	
			
<section id="contact_us">	
    <div class="container">
	<div class="row">
            <div class="col-lg-12 login-key my-align">
                     <span class="login-title " >
                    Purchase History
                </span> 
			</div>
            
			<div class="col-md-12"> 		
 <table id="example" class="table table-striped table-bordered" style="width:100%">
        <thead>
            <tr>
                <th>Name</th>
                <th>Position</th>
                <th>Office</th>
                <th>Age</th>
                <th>Start date</th>
                <th>Salary</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>Tiger Nixon</td>
                <td>System Architect</td>
                <td>Edinburgh</td>
                <td>61</td>
                <td>2011/04/25</td>
                <td>$320,800</td>
            </tr>
        </tbody>
</table>

	</div>
	</div>			
</div>
</section>




<?php 
include('include/footer.php');
?>