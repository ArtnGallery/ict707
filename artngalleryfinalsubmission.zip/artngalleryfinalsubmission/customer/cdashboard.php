<?php 
include('include/header.php');
include('include/connection.php');
?>
	 		
			<section id="contact_us">	
    <div class="container">
        <div class="row">
		<div class="row">
			<div class="col-sm-12 text-center">
				
			</div>
		</div><br>
            <div class="col-lg-12 col-md-10 login-box">
                <div class="col-lg-12 login-key">
                    <i class="fa fa-user" aria-hidden="true"></i> <span class="login-title">
                  Welcome <?php echo $_SESSION['customer_name'];?>
                </span>
                </div>
               <div class="font-icon-list col-lg-2 col-md-2">
               <a  href="vorderpaintings.php"> <i class="fa fa-list red-ico" aria-hidden="true"></i>
                     <p><span>view Ordered Paintings
					</span></p>
					</a>
               </div>
			    <div class="font-icon-list col-lg-2 col-md-2">
                <a  href="purchasehistory.php"><i class="fa fa-shopping-cart blue-ico" aria-hidden="true"></i>
                     <p><span>Purchase History
					</span></p>
					</a>
               </div>
               <div class="font-icon-list col-lg-2 col-md-2">
                <i class="fa fa-cog red-ico" aria-hidden="true"></i>
                     <p><a  href="ucustomer.php"><span>Account Settings
					</span>
					</a></p>
               </div>
			   <div class="font-icon-list col-lg-2 col-md-2">
             <a  href="changepassword.php">   <i class="fa fa-key blue-ico" aria-hidden="true"></i>
                     <p><span>Change Password
					</span></p>
					</a>
               </div>
			   <div class="font-icon-list col-lg-2 col-md-2">
               <a  href="../customer.php"> <i class="fa fa-sign-out red-ico" aria-hidden="true"></i>
                     <p><span>Logout
					</span></p>
					</a>
               </div>

                   <div class="col-lg-3 col-md-2"></div>
            </div>
        </div>



</div>
</section>




<?php 
include('include/footer.php');
?>