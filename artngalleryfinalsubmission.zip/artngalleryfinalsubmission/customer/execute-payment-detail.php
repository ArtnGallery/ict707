<?php 
include('include/header.php');
include('include/connection.php');
?>
	<script>
window.alert('Thank you for Purchasing Painting');
</script>		
			
<section id="contact_us">	
    <div class="container">
	<div class="row">
            <div class="col-lg-12 login-key my-align">
                     <span class="login-title " >
					 Payment Confirmation
					
                </span> 
			</div>
			<div class="col-md-12">
			
			</div>
			<div class="col-md-12"> 
		
 <table id="example" class="table table-striped table-bordered" style="width:100%">
        <thead>
            <tr>
              
                <th>Customer ID</th>
                <th>Customer Name</th>
				
					<th>Painting ID</th>
					<th>Seller ID</th>
					
					<th>Payment ID </th>
					<th>Token ID</th>
                	<th>Payer ID</th>
					<th>
<strong>Total Amount</strong>
</th>
            </tr>
        </thead>
        <tbody>
		<tr>
						

<td><?php echo $_SESSION['customer_id']; ?></td>

        				<td><?php echo $_SESSION['customer_name']; ?></td>
						<?php
						

$paymentId=$_GET['paymentId'];
$token=$_GET['token'];
$PayerID=$_GET['PayerID'];

$query="insert into execute_payment_detail(cid,cname,pid,sid,paymentid,token,payerid,amount,pdate) values('".$_SESSION['customer_id']."','".$_SESSION['customer_name']."','".$_SESSION['paintingid']."','".$_SESSION['seller_id']."','$paymentId','$token','$PayerID','".$_SESSION['checkout']."','".date("Y-m-d")."')";
						 mysqli_query($connect,$query);
						?>
						
						<td><?php echo $_SESSION['paintingid'];?></td>
						<td><?php echo $_SESSION['seller_id'];?></td>
						<td><?php echo $paymentId;?></td>
						<td><?php echo $token; ?></td>
						<td><?php echo $PayerID; ?></td>
						<td>$<?php echo $_SESSION['checkout']?></td>
</tr>
</tbody>
</table>

	</div>
	</div>			
</div>
</section>




<?php 
include('include/footer.php');
?>
