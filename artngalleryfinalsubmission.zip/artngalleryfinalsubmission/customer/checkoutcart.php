<?php 
include('include/header.php');
include('include/connection.php');
?>
	
			
<section id="contact_us">	
    <div class="container">
	<div class="row">
            <div class="col-lg-12 login-key my-align">
                     <span class="login-title " >
                   Checkout Cart
					
                </span> 
			</div>
			<div class="col-md-12">
			
			</div>
			<div class="col-md-12"> 
<form action="final-cart.php" method="post">			
 <table id="example" class="table table-striped table-bordered" style="width:100%">
        <thead>
            <tr>
              <?php
//echo "select * from customer where where cid='".$_SESSION['customer_id']."'";
$Reg_Result = mysqli_query($connect,"select * from customer where cid='".$_SESSION['customer_id']."'");
$Reg_Row = @mysqli_fetch_array($Reg_Result,MYSQLI_ASSOC);
//echo $Reg_Row['address'];

?>
                <th>Customer ID</th>
                <th>Customer Name</th>
				<th>Customer Address</th>
				<th>Customer Contact Number</th>
				<th>Seller ID</th>
               <th>Seller Name</th>
               <th>Painting ID</th>
                <th>Painting Name</th>
				 <th>Painting Cost</th>
            </tr>
        </thead>
        <tbody>
		<?php
		//echo $_SESSION['paintingid'];
		$array =  explode(',', $_SESSION['paintingid']);
		$total=0;
		foreach ($array as $pid) 
		{
			             $query=mysqli_query($connect,"select * from painting_details where pid='$pid'");
                                      if(mysqli_num_rows($query)>0)
                                      {
                                           while($row=mysqli_fetch_array($query))
                                           {
                                               
    

		?>
<tr>
						<td><?php echo $_SESSION['customer_id']; ?></td> 
						
<td >
<?php echo $_SESSION['customer_name']; ?>
</td>
<td><input type="text" value="<?php echo $Reg_Row['address'];?>" name="caddress" required/></td>
<td><input type="text" value="<?php echo $Reg_Row['mobile'];?>" name="cmobile" required/></td>
<td><?php echo $row['sid']; ?></td>
<td><?php echo $row['sname']; ?></td>				    <td><?php echo $row['pid']; ?>
</td>
										<td><?php echo $row['pname']; ?></td>		 
                                                  <td>$<?php echo $row['pprice']; ?></td>

												  <?php $total+=$row['pprice']; ?>
</tr>

		<?php }}}?>
</tbody>
     <tfoot>
<th colspan="4">
<strong>Check Out Total</strong>
</th>
<th colspan="3">
<strong>$<?php echo $total; $_SESSION['checkout']=$total;?></strong>
</th>
<th colspan="2" align="right">
<strong><input type="submit" name="submitcart" value="Checkout Cart"/></strong>
</th> 
</table>
</form>
	</div>
	</div>			
</div>
</section>




<?php 
include('include/footer.php');
?>