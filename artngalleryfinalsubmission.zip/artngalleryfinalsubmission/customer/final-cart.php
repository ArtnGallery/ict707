<?php 
include('include/header.php');
include('include/connection.php');
?>
	
			
<section id="contact_us">	
    <div class="container">
	<div class="row">
            <div class="col-lg-12 login-key my-align">
                     <span class="login-title " >
                   Final Checkout Cart
					
                </span> 
			</div>
			<div class="col-md-12">
			
			</div>
			<div class="col-md-12"> 
<form action="final-cart.php" method="post">			
 <table id="example" class="table table-striped table-bordered" style="width:100%">
        <thead>
            <tr>
              
                <th>Customer ID</th>
                <th>Customer Name</th>
				<th>Customer Address</th>
				<th>Customer Contact Number</th>
				<th>Seller ID</th>
               <th>Seller Name</th>
               <th>Painting ID</th>
                <th>Painting Name</th>
				 <th>Painting Cost</th>
            </tr>
        </thead>
        <tbody>
		<?php
		//echo $_SESSION['paintingid'];
		$array =  explode(',', $_SESSION['paintingid']);
		$total=0;
		foreach ($array as $pid) 
		{
			             $query=mysqli_query($connect,"select * from painting_details where pid='$pid'");
                                      if(mysqli_num_rows($query)>0)
                                      {
                                           while($row=@mysqli_fetch_array($query))
                                           {
                                               
    

		?>
<tr>
						<td><?php echo $_SESSION['customer_id']; ?></td> 
						
<td >
<?php echo $_SESSION['customer_name']; ?>
</td>
<td><?php echo $_POST['caddress'];?></td>
<td><?php echo $_POST['cmobile'];?></td>
<td><?php echo $row['sid']; $_SESSION['seller_id']=$row['sid']; ?></td>
<td><?php echo $row['sname']; ?></td>				    <td><?php echo $row['pid']; ?>
</td>
										<td><?php echo $row['pname']; ?></td>		 
                                                  <td>$<?php echo $row['pprice']; ?></td>

												  <?php $total+=$row['pprice']; ?>
 <?php $query="insert into painting_booking(cid,cname,caddress, cmobile, sid,sname,pid,pname,pprice) values('".$_SESSION['customer_id']."','".$_SESSION['customer_name']."','".$_POST['caddress']."','".$_POST['cmobile']."','".$row['sid']."','".$row['sname']."','".$row['pid']."','".$row['pname']."','".$row['pprice']."')";
@mysqli_query($connect,$query);
						?>
</tr>

		<?php }}}?>
<tr>
<td colspan="4">
<strong>Final Cart Total</strong>
</td>
<td colspan="3">
<strong>$<?php echo $total; $_SESSION['checkout']=$total;?></strong>
</td>
<td colspan="2" align="right">
<div id="paypal-button"></div>
</td> 
</tr>
</tbody>
</table>

</form>
	</div>
	</div>			
</div>
</section>



<script src="https://www.paypalobjects.com/api/checkout.js"></script>
<script>

  paypal.Button.render({
    // Configure environment
    env: 'sandbox',
    client: {
      sandbox: 'AUsvXLsoh2W4_DGqr9OM9EsgzAnX9_-jWwX59XGfIVHHA7Uv-VX4Q8Z0CBlEJXO96gXZa9swJ8dq_PqZ',
      production: 'demo_production_client_id'
    },
    // Customize button (optional)
    locale: 'en_US',
    style: {
      size: 'small',
      color: 'blue',
      shape: 'pill',
    },

    // Enable Pay Now checkout flow (optional)
    commit: true,

    // Set up a payment
    payment: function(data, actions) {
		
	  return actions.payment.create({
	

        transactions: [{
          amount: {
            total: '50',
            currency: 'AUD'
          }
        }],
		redirect_urls:
        {
          return_url: 'http://localhost/artngallery/customer/execute-payment-detail.php',
		}
		
	  
      });
    },
    // Execute the payment
    onAuthorize: function(data, actions) {
      return actions.payment.execute().then(function() {
        // Show a confirmation message to the buyer
    //  window.alert('Thank you for your purchase!');
		return actions.redirect();
      });
    }
  }, '#paypal-button');

</script>

<?php 
include('include/footer.php');
?>
