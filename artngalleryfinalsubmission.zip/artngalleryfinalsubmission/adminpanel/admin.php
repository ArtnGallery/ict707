<?php 
session_start();
include('include/connection.php');
?>
<html>
<head>
	<title>Online art & Gallery</title>
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/style.css" rel="stylesheet">
	<link href="css/custom.css" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="css/font-awesome.min.css" />
	<link rel="stylesheet" type="text/css" href="css/font-awesome.css" />
	<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Muli:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">
<link href='css/simplelightbox.min.css' rel='stylesheet' type='text/css'>
	<script src="js/jquery-2.1.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/ekko-lightbox.js"></script>
	<style>
	.error{
  color:red;
  font-size:14px;
}
	</style>
</head>
<body>

			
				
    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-md-2"></div>
            <div class="col-lg-6 col-md-8 login-box">
		         <div class="col-lg-12 login-key">
                    <i class="fa fa-key" aria-hidden="true"></i>
                </div>
                <div class="col-lg-12 login-title">
                    ADMIN PANEL
                </div>
 

                <div class="col-lg-12 login-form">
                    <div class="col-lg-12 login-form">
                        <form action="admin.php" method="post" id="admin-form">
                            <div class="form-group">
                                <label class="form-control-label">USERNAME</label>
                                <input type="text" class="form-control" name="uname" required>
                            </div>
                            <div class="form-group">
                                <label class="form-control-label">PASSWORD</label>
                                <input type="password" class="form-control" name="pass" required>
                            </div>

                            <div class="col-lg-12 loginbttm">
                                <div class="col-lg-6 login-btm login-text">
                                   <a href="../index.php" class="btn btn-outline-primary">GO BACK</a>
                              </div>
                                <div class="col-lg-6 login-btm login-button">
                                    <button type="submit" name="btn_admin" class="btn btn-outline-primary">LOGIN</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
					<?php 
                         if(isset($_POST['btn_admin']))
                        {
							
                            $uname=trim($_POST['uname']);
                            $pass=md5(trim($_POST['pass']));
                            $query_login=mysqli_query($connect, "select * from myadmin where uname='$uname' and pass='$pass'");
                            if(mysqli_num_rows($query_login)>0)
                             {
								  while($row_login=mysqli_fetch_array($query_login))
                                    {
										

                                $_SESSION['admin_id']=$row_login['id'];
echo '<div class="col-lg-12 alert alert-success">Admin Login Successfully</div>';								                              
                                 header('Refresh: 1;url=index.php');

			                    }
                            }
                             else
                             {
								 echo '<div class="col-lg-12 alert alert-danger">Username and Password mismatch.</div>';
                                 
                            }
						}							
							
                        ?>
       
                <div class="col-lg-3 col-md-2"></div>
            </div>
        </div>



<script>
 $(document).ready(function($) {
        
				$("#admin-form").validate({
                rules: {
                    uname: "required",                    
                    pass: {
                        required: true,
                        minlength: 8
                    }
                 
                },
                messages: {
                    uname: "Please enter Username",                   
                    pass: {
                        required: "Please provide a password",
                        minlength: "Your password must be at least 8 characters long"
                    }
                },
                 
                submitHandler: function(form) {
                    form.submit();
                }
                
            });
    });
	</script>


			
</body>
</html>
<script type="text/javascript" src="js/jquery.validate.min.js"></script>
<script type="text/javascript" src="js/simple-lightbox.js"></script>