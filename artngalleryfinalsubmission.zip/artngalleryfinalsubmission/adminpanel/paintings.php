<?php 
ob_start();
include('include/header.php');
include('include/connection.php');
?>		
			<section id="contact_us">	
    <div class="container">
        <div class="row">
		<div class="row">
			<div class="col-sm-12 text-center">
				
			</div>
		</div><br>
            <div class="col-lg-3 col-md-2"></div>
            <div class="col-lg-6 col-md-8 login-box">
                <div class="col-lg-12 login-key">
                    <i class="fa fa-plus-square" aria-hidden="true"></i> <span class="login-title">
                    Add Paintings
                </span>
                </div>
               

                <div class="col-lg-12 login-form">
                    <div class="col-lg-12 login-form">
                        <form action="paintings.php" method="post" id="cat-form" enctype="multipart/form-data">
                            <?php

$Reg_Result = mysqli_query($connect,"select * from painting_details ORDER BY id desc");
$Reg_Row = @mysqli_fetch_array($Reg_Result,MYSQLI_ASSOC);

?>
                            <div class="form-group">
                                <label class="form-control-label">Painting ID</label>
                                <input type="text" name="pid" value="<?php echo 'PT'.($Reg_Row['id']+1); ?>" class="form-control" readonly>
                            </div>
							<div class="form-group">
							
                                <label class="form-control-label">Select Category</label>
                                <select name="scat" class="form-control">
<option>--Select Category--</option>
							<?php

$query = mysqli_query($connect,"select * from category ORDER BY id desc");
 if(mysqli_num_rows($query)>0)
                                      {
                                           while($row=mysqli_fetch_array($query))
                                           {
                                                
?><option value="<?php echo $row['cid']; ?>"><?php echo $row['cname'];?></option>
									  <?php }}?>
								</select>
								</div>
<div class="form-group">
                                <label class="form-control-label">Painting Name</label>
                                <input type="text" name="pname" class="form-control" required>
                            </div>
							<div class="form-group">
                                <label class="form-control-label">Painting Description</label>
                                <input type="text" name="pdesc" class="form-control" required>
                            </div>
							<div class="form-group">
                                <label class="form-control-label">Painting Price($)</label>
                                <input type="text" name="pprice" class="form-control" required>
                            </div>
<div class="form-group">
                                <label class="form-control-label">Painting Quantity</label>
                                <input type="text" name="pquantity" class="form-control" required>
                            </div>
							<div class="form-group">
                                <label class="form-control-label">Painting Features</label>
                                <textarea class="form-control" rows="5" id="highlight" name="pfeatures"></textarea>  
								</div>
								<div class="form-group">
                                <label class="form-control-label">Upload Painting Photo</label>
                                <input name="pimage" class=" form-control" type="file">  
								</div>
                            <div class="col-lg-12 loginbttm">
                                <div class="col-lg-6 login-btm login-text">
                                   
                                </div>
                                <div class="col-lg-6 login-btm login-button">
                                    <button type="submit" name="btn_cat" class="btn btn-outline-primary">SUBMIT</button>
                                
								 </div>
                            </div>
                        </form>
                    </div>
                </div>
				<?php
                              if(isset($_POST['btn_cat']))
                              {
                                   
                                   $pid=trim($_POST['pid']);
                                   $scat=trim($_POST['scat']);
								   $pname=trim($_POST['pname']);
                                   $pdesc=trim($_POST['pdesc']);
								   $pprice=trim($_POST['pprice']);
								   $pquantity=trim($_POST['pquantity']);
								   $pfeatures=trim($_POST['pfeatures']);
								     if(isset($_FILES['pimage']))
	{
		$name=strtolower($_FILES['pimage']['name']);
		$tmp_name=$_FILES['pimage']['tmp_name'];
		$ext=pathinfo($name,PATHINFO_EXTENSION);
		$compare=array('gif','jpeg','jpg','png');
		if(isset($name))
		{
			if(!empty($name))
			{
				if(in_array($ext,$compare))
				{
					$location='upload/';
					if(file_exists($location.$name))
					{
						$l=3;
						$c='abcdefghijklmnopqrstuvwxyz';
						$name='';
						for($i=0;$i<=$l;$i++)
						{
							$name.=$c[rand(0,strlen($c))];
							}
							$name=$name.'.'.$ext;
					}
					if(move_uploaded_file($tmp_name,$location.$name))
					{
						$loc_file=$location.$name;
						$query="insert into painting_details(pid,cid,sid,sname,pname, pdesc,pprice,pquantity, pfeatures,pimg) values('$pid','$scat','admin','admin','$pname','$pdesc','$pprice','$pquantity','$pfeatures','$loc_file')";
						 if(mysqli_query($connect,$query))
        {
			                  
            echo '<div class="col-lg-12 alert alert-success">Painting details Added Successfully.</div>';
			
        }
        else
        {
            echo '<div class="col-lg-12  alert alert-danger">Problem Occured.</div>';
        }
					}
				}
				else
				{
					echo '<div class="col-lg-12  alert alert-danger">Enter a valid image';
				}
			}
			else
				{
					echo '<div class="col-lg-12  alert alert-danger">Select Image';
				}
		}
	}
	
                        }
                      ?>
        
            </div>
        </div>



</div>
</section>

<script>
  $(document).ready(function($) {
        
				$("#cat-form").validate({
                rules: {
                      cname:"required"                
                    
                },
                messages: {
                                       
                    cname: "Please enter Category Name"
                },
                 
                submitHandler: function(form) {
                    form.submit();
                }
                
            });
    });
	</script>


<?php 
include('include/footer.php');
ob_end_flush();
?>