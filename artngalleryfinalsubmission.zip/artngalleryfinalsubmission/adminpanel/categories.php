<?php 
ob_start();
include('include/header.php');
include('include/connection.php');
?>		
			<section id="contact_us">	
    <div class="container">
        <div class="row">
		<div class="row">
			<div class="col-sm-12 text-center">
				
			</div>
		</div><br>
            <div class="col-lg-3 col-md-2"></div>
            <div class="col-lg-6 col-md-8 login-box">
                <div class="col-lg-12 login-key">
                    <i class="fa fa-list" aria-hidden="true"></i> <span class="login-title">
                    Add Categories
                </span>
                </div>
               

                <div class="col-lg-12 login-form">
                    <div class="col-lg-12 login-form">
                        <form action="categories.php" method="post" id="cat-form" enctype="multipart/form-data">
                            <?php

$Reg_Result = mysqli_query($connect,"select * from category ORDER BY id desc");
$Reg_Row = @mysqli_fetch_array($Reg_Result,MYSQLI_ASSOC);

?>
                            <div class="form-group">
                                <label class="form-control-label">Categories ID</label>
                                <input type="text" name="cid" value="<?php echo 'CG'.($Reg_Row['id']+1); ?>" class="form-control" readonly>
								</div>
<div class="form-group">
                                <label class="form-control-label">Categories Name</label>
                                <input type="text" name="cname" class="form-control" required>
                            </div>
							<div class="form-group">
                                <label class="form-control-label">Upload Category Photo</label>
                                <input name="cimg" class=" form-control" type="file">  
								</div>
                            <div class="col-lg-12 loginbttm">
                                <div class="col-lg-6 login-btm login-text">
                                   
                                </div>
                                <div class="col-lg-6 login-btm login-button">
                                    <button type="submit" name="btn_cat" class="btn btn-outline-primary">SUBMIT</button>
                                
								 </div>
                            </div>
                        </form>
                    </div>
                </div>
				<?php
                              if(isset($_POST['btn_cat']))
                              {
                                   
                                   $cid=trim($_POST['cid']);
                                   $cname=trim($_POST['cname']);
   if(isset($_FILES['cimg']))
	{
		$name=strtolower($_FILES['cimg']['name']);
		$tmp_name=$_FILES['cimg']['tmp_name'];
		$ext=pathinfo($name,PATHINFO_EXTENSION);
		$compare=array('gif','jpeg','jpg','png');
		if(isset($name))
		{
			if(!empty($name))
			{
				if(in_array($ext,$compare))
				{
					$location='upload/';
					if(file_exists($location.$name))
					{
						$l=3;
						$c='abcdefghijklmnopqrstuvwxyz';
						$name='';
						for($i=0;$i<=$l;$i++)
						{
							$name.=$c[rand(0,strlen($c))];
							}
							$name=$name.'.'.$ext;
					}
					if(move_uploaded_file($tmp_name,$location.$name))
					{
						$loc_file=$location.$name;
						$query="insert into category(cid,cname,cimg,cstatus) values('$cid','$cname','$loc_file','1')";
						 if(mysqli_query($connect,$query))
        {
			                  
            echo '<div class="col-lg-12 alert alert-success">Category Added Successfully.</div>';
			
        }
        else
        {
            echo '<div class="col-lg-12  alert alert-danger">Problem Occured.</div>';
        }
					}
				}
				else
				{
					echo '<div class="col-lg-12  alert alert-danger">Enter a valid image';
				}
			}
			else
				{
					echo '<div class="col-lg-12  alert alert-danger">Select Image';
				}
		}
	}
	
                        }
                      ?>
        
            </div>
        </div>



</div>
</section>

<script>
  $(document).ready(function($) {
        
				$("#cat-form").validate({
                rules: {
                      cname:"required"                
                    
                },
                messages: {
                                       
                    cname: "Please enter Category Name"
                },
                 
                submitHandler: function(form) {
                    form.submit();
                }
                
            });
    });
	</script>


<?php 
include('include/footer.php');
ob_end_flush();
?>