<?php 
include('include/header.php');
include('include/connection.php');
?>
	
			
<section id="contact_us">	
    <div class="container">
	<div class="row">
            <div class="col-lg-12 login-key my-align">
                     <span class="login-title " >
                    View Ordered Paintings
                </span> 
			</div>
            		
			<div class="col-md-12"> 		
 <table id="example" class="table table-striped table-bordered" style="width:100%">
        <thead>
            <tr>
                <th>Ordered ID</th>
				<th>Customer ID</th>
                <th>Customer Name</th>
				<th>Customer Address</th>
				<th>Customer Contact Number</th>
				<th>Seller ID</th>
               <th>Seller Name</th>
               <th>Painting ID</th>
                <th>Painting Name</th>
				 <th>Painting Cost</th>
            </tr>
        </thead>
        <tbody>
		<?php
                                      $query=mysqli_query($connect,"select * from painting_booking");
                                      if(mysqli_num_rows($query)>0)
                                      {
                                           while($row=mysqli_fetch_array($query))
                                           {
                                                ?>
            <tr>
               <td><?php echo $row['id']; ?></td>
                 <td><?php echo $row['cid']; ?></td>
               <td><?php echo $row['cname']; ?></td>
                                     <td><?php echo $row['caddress']; ?></td>
               <td><?php echo $row['cmobile']; ?></td>
            
                                <td><?php echo $row['sid']; ?></td>
								 <td><?php echo $row['sname']; ?></td>
								  <td><?php echo $row['pid']; ?></td>
								  <td><?php echo $row['pname']; ?></td>
								  <td>$<?php echo $row['pprice']; ?></td>
								  </tr>
			 <?php
                                           }   
                                      } 
                                      ?>
        </tbody>
</table>

	</div>
	</div>			
</div>
</section>




<?php 
include('include/footer.php');
?>