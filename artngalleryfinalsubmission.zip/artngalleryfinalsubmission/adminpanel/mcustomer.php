<?php 
include('include/header.php');
include('include/connection.php');
?>
	
			
<section id="contact_us">	
    <div class="container">
	<div class="row">
            <div class="col-lg-12 login-key my-align">
                     <span class="login-title " >
                    Manage Customers
                </span> 
			</div>
            <div class="col-md-12"> 
            <?php
                          if(isset($_GET['id']))
                          {
                            
                            $query_delete=mysqli_query($connect,"delete from customer where cid='".$_GET['id']."'");
                            if(mysqli_affected_rows($connect)>0)
                            {
								echo '<div class="alert alert-success">Customer Record deleted Successfully</div>';
								 
								}
                          }
                           ?></div>
			<div class="col-md-12"> 		
 <table id="example" class="table table-striped table-bordered" style="width:100%">
        <thead>
            <tr>
                <th>Customer ID</th>
                <th>Full Name</th>
               <th>Username</th>
               <th>Email</th>
			   <th>Mobile</th>
			   
			   <th>Address</th>
			   
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
		<?php
                                      $query=mysqli_query($connect,"select * from customer");
                                      if(mysqli_num_rows($query)>0)
                                      {
                                           while($row=mysqli_fetch_array($query))
                                           {
                                                ?>
            <tr>
               <td><?php echo $row['cid']; ?></td>
                                                  
                <td><?php echo $row['fullname']; ?></td>
                                <td><?php echo $row['uname']; ?></td>
								 <td><?php echo $row['email']; ?></td>
								  <td><?php echo $row['mobile']; ?></td>
								  <td><?php echo $row['address']; ?></td>
          <td><a href="ucustomer.php?id=<?php echo $row['cid'] ?>" class="btn btn-primary btn-xs">Update</a>
												  <a href="mcustomer.php?id=<?php echo $row['cid'] ?>" onClick="return confirm('Are You Sure to Delete?')" class="btn btn-danger btn-xs">Delete</a>
												  </td>  
												                                   
            </tr>
			 <?php
                                           }   
                                      } 
                                      ?>
        </tbody>
</table>

	</div>
	</div>			
</div>
</section>




<?php 
include('include/footer.php');
?>