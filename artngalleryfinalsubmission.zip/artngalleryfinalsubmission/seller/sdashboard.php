<?php 
include('include/header.php');
include('include/connection.php');
?>
	 		
			<section id="contact_us">	
    <div class="container">
        <div class="row">
		<div class="row">
			<div class="col-sm-12 text-center">
				
			</div>
		</div><br>
           <div class="col-lg-12 col-md-10 login-box2">
                <div class="col-lg-12 login-key">
                      <i class="fa fa-user" aria-hidden="true"></i> <span class="login-title">
                  Welcome <?php echo $_SESSION['seller_name'];?>
                </span>
                </div>
				<div class="row">
<div class="col-md-3">
          <div class="box">
            <i class="fa fa-info-circle alert-info"></i>
            <div class="info">
              <h3 class="red-ico">Overall</h3> <span></span>
              <p>Quick Info</p>
            </div>
          </div>
        </div>
	  <div class="col-md-3">
          <div class="box">
            <i class="fa fa-user alert-success"></i>
            <div class="info">
              <h3 class="blue-ico">
			  <?php 
                          $query = "SELECT COUNT(*) FROM painting_details where sid='".$_SESSION['seller_id']."' ";
                          $result = mysqli_query($connect, $query) or die(mysqli_error($db));
                          while ($row = mysqli_fetch_array($result)) {
                              echo "$row[0]";
                            }
                          ?>
			  </h3> <span></span>
              <p>Paintings(s)</p>
            </div>
          </div>
        </div>
        <div class="col-md-3">
          <div class="box">
            <i class="fa fa-user alert-warning"></i>
            <div class="info">
              <h3 class="red-ico"><?php 
                          $query = "SELECT COUNT(*) FROM painting_booking where sid='".$_SESSION['seller_id']."'";
                          $result = mysqli_query($connect, $query) or die(mysqli_error($db));
                          while ($row = mysqli_fetch_array($result)) {
                              echo "$row[0]";
                            }
                          ?></h3> <span></span>
              <p>Painting Sold(s)</p>
            </div>
          </div>
        </div>
		</div>
               <div class="font-icon-list col-lg-2 col-md-2">
                <a  href="mpaintings.php"><i class="fa fa-list blue-ico" aria-hidden="true"></i>
                     <p><span>Manage Paintings
					</span></p>
					</a>
               </div>
			    <div class="font-icon-list col-lg-2 col-md-2">
               <a  href="purchasehistory.php"> <i class="fa fa-shopping-cart red-ico" aria-hidden="true"></i>
                     <p><span>Purchase History
					</span>
					</p></a>
               </div>
               <div class="font-icon-list col-lg-2 col-md-2">
                <a  href="useller.php"><i class="fa fa-cog blue-ico" aria-hidden="true"></i>
                     <p><span>Account Settings
					</span></p>
					</a>
               </div>
			   <div class="font-icon-list col-lg-2 col-md-2">
                <a  href="changepassword.php"><i class="fa fa-key red-ico" aria-hidden="true"></i>
                     <p><span>Change Password
					</span>
					</p></a>
               </div>
			   <div class="font-icon-list col-lg-2 col-md-2">
                <a  href="../seller.php"><i class="fa fa-sign-out blue-ico" aria-hidden="true"></i>
                     <p><span>Logout
					</span></p>
					</a>
               </div>

                   <div class="col-lg-3 col-md-2"></div>
            </div>
        </div>



</div>
</section>




<?php 
include('include/footer.php');
?>