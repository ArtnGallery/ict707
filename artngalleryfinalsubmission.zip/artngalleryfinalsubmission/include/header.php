<?php session_start()?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Online Art & Gallery</title>
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/style.css" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="css/font-awesome.min.css" />
	<link rel="stylesheet" type="text/css" href="css/font-awesome.css" />
	
	<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Muli:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">
<link href='css/simplelightbox.min.css' rel='stylesheet' type='text/css'>
	<script src="js/jquery-2.1.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/ekko-lightbox.js"></script>
<link href="https://cdn.datatables.net/1.10.21/css/dataTables.bootstrap4.min.css" rel="stylesheet">


  </head>
<body>


<section id="header" class="clearfix navbar-inverse navbar-fixed-top">

	<nav class="navbar navbar-default ">
        <div class="container clearfix">
		    
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header clearfix page-scroll">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
				<a href="index.php" class="navbar-brand">Online <span>Art Gallery</span></a>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse clearfix" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
                    
					
					<li>
                        <a class="tag_menu" href="categories.php">Categories</a>
                    </li>
					
                    
					<li>
                        <a class="tag_menu" href="gallery.php">Gallery</a>
                    </li>
					
					<li>
                        <a class="tag_menu" href="contact.php">Contact us</a>
                    </li>
					
					
					
			<!--		<li class="dropdown"><a class="tag_menu" href="#" data-toggle="dropdown"><span class="fa fa-search"></span></a>
							<ul class="dropdown-menu drop_1" style="min-width: 300px;">
								<li>
									<div class="row_1">
										<div class="col-sm-12">
											<form class="navbar-form navbar-left" role="search">
											<div class="input-group">
												<input type="text" class="form-control" placeholder="Search">
												<span class="input-group-btn">
													<button class="btn btn-primary" type="button">
														Search</button>
												</span>
											</div>
											</form>
										</div>
									</div>
								</li>
							</ul>
						</li>
					-->	
					<li class="dropdown">
						  <a class="tag_menu border_none" href="#" data-toggle="dropdown" role="button" aria-expanded="false">MORE<span class="caret"></span></a>
						  <ul class="dropdown-menu drop_2" role="menu">
							<li>
                        <a  href="seller.php">Seller Login</a>
                    </li>
<li>
                        <a  href="customer.php">Customer Login</a>
                    </li>
<!--<li>
                        <a  href="adminpanel/admin.php">Admin Login</a> 
                    </li>-->	
					</ul>
						</li>
					
                </ul>
				 
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container-fluid -->
    </nav>
	
</section>